//@@viewOn:imports
import UU5 from "uu5g04";
//@@viewOff:imports

export const TripsContext = UU5.Common.Context.create();
export default TripsContext;
